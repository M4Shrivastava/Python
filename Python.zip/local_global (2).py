
# Q2.Describe local variable and global variable code.

"""Global variables are declared outside any function or class,
while local variables are declared within a function or block of code."""

"""Local variables are declared within a function
 or block of code and can only be used within that specific function or block.
 They are not accessible outside of their scope."""

def my_code():
    local = 131  # This is a local variable
    print("Inside the function, local:", local)

my_code()
# print(local)
# This would raise an error because local_var is not accessible here.

"""Global Variables
Global variables are declared outside of all functions and blocks.
They can be accessed and modified from any function or block
within the same module or script."""

name = "mini"

def my_global():
    global name
    # This tells Python that we are referring to the global variable
    name = "kratika"

def my_global():
    print("Global variable value:",name)

my_global()
print (name)  # Outputs: Global variable value: mini
