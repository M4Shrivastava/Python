#Q5. Write a code for string, int and float input.

name= input("Write your name: ") # Here inpute type is string.
print(name)
age = int(input("Write your age: ")) # Here input type is integer.
print(age)
salary = float(input('Write your salary: ')) # Here input type is float. 
print(salary)
print("Thank you..!")

