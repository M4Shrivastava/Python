
#Q4. Write a code that describes local and global variable with same name.

Identity_var = "GLOBAL" # Here identity_var is identifier and value is "GLOBAL" which we want to print. 

def Doof1001():
 Identity_var = "LOCAL" # Here identifier is same but value is different i.e. LOCAL.
 print( Identity_var )
Doof1001()
    
print( Identity_var )

# In this code we use the same identifier for both the global and local variables but with different values.