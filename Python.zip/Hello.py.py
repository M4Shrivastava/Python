
#Q1. Python program to display "Hello world!".

print("Hello world!")

# Hello world is the first function in every coding languages.
"""print("Hello, World!") The print() function is foundational, and mastering it will serve you well in your Python journey.
 It accepts one or more arguments, making it versatile enough to display strings, variables, or even complex expressions as output."""
