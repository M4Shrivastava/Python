
# Q3. write a code that describe indentation error.

if 10>5:
 Answer = "Yes its true"
   print(Answer)

 """Indentation error in python is very sensitive to indentation
 so you have to give it to indentaion its different from other programming
 languages so if you run this code now you will see error
 its indenataion error that's because this ( print(y)) is no way indented."""
 

